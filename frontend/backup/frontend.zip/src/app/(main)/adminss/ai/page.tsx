import { requireAdmin } from "@/features/admin/server"
import { AdminAiIndexPage } from "@/features/admin/components/admin-ai-index-page"

export default async function AdminAiPage() {
    await requireAdmin()

    return <AdminAiIndexPage />
}
