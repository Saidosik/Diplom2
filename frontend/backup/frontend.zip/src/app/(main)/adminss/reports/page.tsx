import { requireAdmin } from "@/features/admin/server"
import { AdminReportsPage } from "@/features/admin/components/admin-reports-page"

export default async function AdminReportsRoute() {
    await requireAdmin()

    return <AdminReportsPage />
}
