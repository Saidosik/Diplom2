import { requireAdmin } from "@/features/admin/server"
import { AdminUsersPage } from "@/features/admin/components/admin-users-page"

export default async function AdminUsersRoute() {
    await requireAdmin()

    return <AdminUsersPage />
}
