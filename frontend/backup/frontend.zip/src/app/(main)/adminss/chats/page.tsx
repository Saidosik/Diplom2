import { requireAdmin } from "@/features/admin/server"
import { AdminChatsPage } from "@/features/admin/components/admin-chats-page"

export default async function AdminChatsRoute() {
    await requireAdmin()

    return <AdminChatsPage />
}
